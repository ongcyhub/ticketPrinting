/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ticketprinting;

/**
 *
 * @author OngCY
 */
public class ticketConfig {

   
    public static final String configFile = "F:\\workspace\\ticketPrinting\\src\\ticketprinting\\config.xml";
    public static final String resultPrefix = "output";
    public static final String resultExt = ".csv";
    public static final String systemCRLF = "\r\n";
}
